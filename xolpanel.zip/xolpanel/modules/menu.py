from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
inline = [
[Button.inline("[ SSH Menu ]","ssh"),
Button.inline("[ Trial SSH ]","trial-ssh")],
[Button.url("[ WhatsApp ]","https://wa.me/+6285225416745"),
Button.url("[ Telegram ]","https://t.me/RidwanzSaputra")]]
sender = await event.get_sender()
val = valid(str(sender.id))
if val == "false":
try:
await event.answer("Akses Ditolak", alert=True)
except:
await event.reply("Akses Ditolak")
elif val == "true":
msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**⟨ ADMIN PANEL MENU ⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Bot Version:** `v5.0`
**» Bot By:** `@RidwanzSaputra`
**◇━━━━━━━━━━━━━━━━━◇**
"""
x = await event.edit(msg,buttons=inline)
if not x:
await event.reply(msg,buttons=inline)