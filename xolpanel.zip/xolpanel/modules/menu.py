from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("[ ssʜ ᴍᴇɴᴜ ]","ssh"),
Button.inline("[ ᴛʀɪᴀʟʟ ssʜ ]","trial-ssh")],
[Button.url("[ ᴡʜᴀᴛsᴀᴘᴘ ]","https://wa.me/+6285225416745"),
Button.url("[ ᴛᴇʟᴇɢʀᴀᴍ ]","https://t.me/RidwanzSaputra")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Access Denied!", alert=True)
		except:
			await event.reply("Access Denied!")
	elif val == "true":
		msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ ADMIN PANEL MENU ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» Bot Versions:** `v1.0`
**» Bot By:** @RidwanzSaputra
**◇━━━━━━━━━━━━━━━━◇**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)