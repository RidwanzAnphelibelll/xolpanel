from xolpanel import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline("[ ᴄʀᴇᴀᴛᴇ ssʜ ]","create-ssh"),
Button.inline("[ ᴛʀɪᴀʟʟ ssʜ ]","trial-ssh")],
[Button.inline("[ ᴅᴇʟᴇᴛᴇ ssʜ ]","delete-ssh"),
Button.inline("[ sʜᴏᴡ ᴀʟʟ ᴜsᴇʀ ssʜ ]","show-ssh")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ SSH Menu Manager ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» Service:** `SSH`
**» Host:** `{DOMAIN}`
**» Ns:** `{SLDOMAIN}`
**» ISP:** `{z["isp"]}`
**» Region:** `{z["region"]}`
**» Timezone:** `{z["timezone"]}`
**» 🤖@RdwnzVPN_bot**
**◇━━━━━━━━━━━━━━━━◇**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied!",alert=True)